VERSION = '0.0.4'
from .application import point_install_to_child_dir, point_install_to_current_dir
